CREATE OR ALTER PROCEDURE AUDITORIA_ANA_C_1 (
    dia date,
    dataini date,
    datafin date,
    codalmox integer)
returns (
    titulo varchar(18),
    emissao date,
    dataconsolida date,
    caixa smallint,
    formapagamento char(1),
    datavencimento date,
    codfornecedor integer,
    valortitulo double precision,
    valor_resto double precision,
    valor_prim_via double precision,
    status char(16),
    datapagamento date,
    datainclusao date,
    valorrecebido double precision,
    nomefornecedor varchar(60),
    valorrec double precision,
    codpagamento integer,
    perda double precision)
as
declare variable nomeccusto varchar(5);
declare variable x integer;
BEGIN
  x = 1;
  FOR
    select
    pagamento.titulo,
    pagamento.emissao,
    pagamento.dataconsolida,
    pagamento.caixa,
    pagamento.formapagamento,
    pagamento.datavencimento,
    pagamento.codfornecedor ,
    movimentodetalhe.preco,

    0 , --compra.valor,

    movimentodetalhe.preco,
    CASE pagamento.STATUS WHEN '5-' THEN 'PENDENTE' when '6-' then 'PENDENTE CONTAB.' when '7-' then 'PAGO' when '8-' then 'SUSPENSO' END AS STATUS,
    pagamento.datapagamento,
    pagamento.datainclusao ,
    pagamento.perda,
    movimentodetalhe.preco,
    fornecedor.nomefornecedor--,
  --  movimentodetalhe.preco

from movimentodetalhe
   inner join produtos on (movimentodetalhe.codproduto = produtos.codproduto)
   inner join plano on (produtos.conta_despesa = plano.conta)
   inner join compra on (movimentodetalhe.codmovimento = compra.codmovimento)
   inner join pagamento on (compra.codcompra = pagamento.codcompra)
   inner join fornecedor on (pagamento.codfornecedor = fornecedor.codfornecedor)
where 
   (
    --  (movimentodetalhe.codmovimento = 133583)
      pagamento.datainclusao between :dataini and :datafin  AND pagamento.CODALMOXARIFADO = :codalmox
   )

    INTO :TITULO,
         :EMISSAO,
         :DATACONSOLIDA,
         :CAIXA,
         :FORMAPAGAMENTO,
         :DATAVENCIMENTO,
         :CODFORNECEDOR,
         :VALORTITULO,
         :VALOR_RESTO,
         :VALOR_PRIM_VIA,
         :STATUS,
         :DATAPAGAMENTO,
         :DATAINCLUSAO ,
         :PERDA ,
         :VALORRECEBIDO,
         :NOMEFORNECEDOR--,
       --  :VALORREC
  DO
  BEGIN

   if(status = 'PAGO')then
   begin
   if ( x = 1) then
   VALORRECEBIDO = ( VALORRECEBIDO - perda);
   end
    if((:dia < :datapagamento) or (:dia = :datapagamento)) then
    begin
      if(status = 'PAGO')then
      status = 'PENDENTE';
     if ( x = 1) then
     begin
     valorrec = (valorrecebido + perda);
     end else
      valorrec = (valorrecebido) ;
      valorrecebido = 0;
    end
    SUSPEND;
    x = x + 1;

    valorrec =0;
  END
END
